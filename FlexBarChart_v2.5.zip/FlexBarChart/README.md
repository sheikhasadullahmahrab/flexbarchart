# FlexBarChart — Qlik Sense Extension

A fully open-source (MIT) D3 v7 bar chart extension for Qlik Sense.
Publish, modify, and distribute under your own name with zero restrictions.

---

## Chart modes

| Mode | Description | Reference |
|---|---|---|
| **Grouped** | Side-by-side bars per category | Images 1 & 2 |
| **Stacked** | Segments stacked in one bar per category | Image 1 |
| **Stacked Grouped** | Multiple stacked bars per category | Images 3 & 4 |
| **Nested / Inset** | Sub-metric bars rendered inside a parent "overall" bar | Images 5 & 6 |

Switch between modes at runtime from the **Chart settings → Chart mode** dropdown — no reload required.

---

## Theme system

### Priority order (highest → lowest)

```
Qlik app/master theme  →  chart-level palette override  →  style preset  →  built-in fallback
```

1. **Qlik app theme** — if your Qlik tenant has a master theme applied (via `qlik.currApp().theme`), its `dataColors` array is read automatically and used as the series palette.
2. **Custom palette** — enter comma-separated hex values in **Theme → Custom series colors** (e.g. `#FF3B30, #007AFF, #34C759`). These override the preset palette per series.
3. **Palette preset** — choose from Default, iOS, Material, Flat, or Corporate in the property panel.
4. **Style preset** — controls geometry and typography (see below), independently of colors.

### Style presets

| Preset | Bar corners | Shadows | Font | Tooltip |
|---|---|---|---|---|
| **iOS** | 8 px rounded | Soft drop shadow | SF Pro / system | Frosted glass blur |
| **Material** | 4 px rounded | Elevation shadow | Roboto | White card + shadow |
| **Flat / Minimal** | 3 px | None | Inter | Dark pill |
| **Corporate** | 2 px | None | Calibri / Segoe UI | White bordered box |

Style and palette presets are independent — you can combine "iOS geometry" with a "Corporate palette".

---

## Installation

### Qlik Sense Desktop
1. Copy the entire `FlexBarChart/` folder into:
   `C:\Users\<you>\Documents\Qlik\Sense\Extensions\`
2. Restart Qlik Sense Desktop.
3. The extension appears in the **Custom objects** panel as **FlexBarChart**.

### Qlik Sense Enterprise (QSEoW)
1. Zip the folder → `FlexBarChart.zip`
2. QMC → **Extensions** → **Import** → upload the zip.
3. The extension is immediately available on all sheets.

### Qlik Cloud (SaaS)
1. Zip the folder → `FlexBarChart.zip`
2. Management Console → **Extensions** → **Add** → upload the zip.

---

## Adding D3 v7

The extension loads D3 from `./lib/d3.v7.min.js`.

Download D3 v7 and place it at:
```
FlexBarChart/
└── lib/
    └── d3.v7.min.js
```

Download from: https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js

Alternatively, change the `define([...])` path in `renderer.js` to load from a CDN:
```js
"https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js"
```
(Note: CDN loading requires internet access from the Qlik server.)

---

## Data structure

### Grouped / Stacked
- **1 Dimension** — chart categories (x-axis labels)
- **N Measures** — one per series / color group

### Stacked Grouped
- **1–2 Dimensions** — dim 0 = category, dim 1 (optional) = sub-group
- **N Measures** — stacked within each sub-group bar
- If using 1 dimension, enter sub-group names in **Chart settings → Sub-group keys**

### Nested / Inset
- **1 Dimension** — chart categories (y-axis labels, horizontal chart)
- **N Measures** — first measure = parent/overall bar; remaining = child inset bars
- Set the parent measure name in **Chart settings → Parent / Overall measure name**

---

## Customising themes

### Add a new style preset
In `themes.js`, add a new key to `STYLE_PRESETS`:

```js
myBrand: {
  name: "My Brand",
  barRadius: 6,
  barRadiusBottom: 0,
  barPaddingInner: 0.3,
  barPaddingOuter: 0.2,
  groupPaddingInner: 0.08,
  segmentGap: 2,
  shadow: true,
  shadowColor: "rgba(0,100,200,0.15)",
  shadowBlur: 10,
  shadowOffsetY: 4,
  fontFamily: "'My Brand Font', sans-serif",
  fontSize: 12,
  labelColor: "#334155",
  axisColor: "#CBD5E1",
  gridColor: "#F1F5F9",
  gridDash: "0",
  tooltipBg: "#1E293B",
  tooltipRadius: 8,
  tooltipBorder: "none",
  tooltipTextColor: "#F8FAFC",
  animationDuration: 350,
  animationEasing: "cubic-bezier(0.34,1.56,0.64,1)",
  legendShape: "circle",
  legendFontSize: 12
}
```

### Add a new color palette
In `themes.js`, add a key to `PALETTES`:

```js
myBrand: [
  "#0057FF", "#00B894", "#FDCB6E", "#E17055",
  "#6C5CE7", "#00CEC9", "#FD79A8", "#2D3436"
]
```

Both will appear automatically in the property panel dropdowns.

---

## Files

```
FlexBarChart/
├── FlexBarChart.qext   — Extension manifest (name, version, icon)
├── FlexBarChart.js     — Main entry point: Qlik lifecycle + data parsing
├── renderer.js              — D3 rendering engine (all four chart modes)
├── themes.js                — Theme engine (palette + style preset resolution)
├── properties.js            — Qlik property panel definition
├── lib/
│   └── d3.v7.min.js         — D3 v7 (download separately — see above)
├── preview.png              — Thumbnail shown in Qlik's extension picker
└── README.md                — This file
```

---

## License

MIT — free to use, modify, and publish under your own name.
